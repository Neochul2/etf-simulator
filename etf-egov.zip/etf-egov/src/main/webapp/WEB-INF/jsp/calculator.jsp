<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>월배당 ETF - 배당금 계산기</title>
<link href="<%=request.getContextPath()%>/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background-color: #f8f9fa; }
.navbar-brand { font-weight: bold; }
.nav-link.active { border-bottom: 3px solid #0d6efd; font-weight: bold; }
.badge-screen { background-color: #0d6efd; }
.logo-box { width: 56px; height: 56px; background: #4338ca; color: #fff;
    display: flex; align-items: center; justify-content: center;
    font-weight: bold; border-radius: 10px; }
.result-card { background: #fff; border-radius: 8px; padding: 14px; text-align: center; }
.autocomplete-box {
    position: absolute; z-index: 9999; background: #fff;
    border: 1px solid #dee2e6; border-radius: 6px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    max-height: 220px; overflow-y: auto; width: 100%;
}
.autocomplete-item { padding: 8px 12px; cursor: pointer; font-size: 0.9rem; }
.autocomplete-item:hover, .autocomplete-item.active { background-color: #e9f0ff; color: #0d6efd; }
.autocomplete-wrap { position: relative; }
</style>
</head>
<body>

<nav class="navbar navbar-expand bg-white border-bottom mb-4">
    <div class="container">
        <a class="navbar-brand" href="<%=request.getContextPath()%>/etf/list.do">📊 미국 월배당 ETF</a>
        <ul class="navbar-nav mx-auto">
            <li class="nav-item"><a class="nav-link" href="<%=request.getContextPath()%>/etf/list.do">ETF 조회</a></li>
            <li class="nav-item"><a class="nav-link active" href="<%=request.getContextPath()%>/etf/calculator.do">배당금 계산기</a></li>
            <li class="nav-item"><a class="nav-link" href="<%=request.getContextPath()%>/etf/simulator.do">재투자 시뮬레이션</a></li>
            <li class="nav-item"><a class="nav-link" href="<%=request.getContextPath()%>/etf/portfolio.do">내 포트폴리오</a></li>
        </ul>
        <div class="d-flex align-items-center ms-3">
            <span class="text-muted me-2" style="font-size:0.85rem;">
                💱 <span id="navExchangeRate">-</span> KRW
            </span>
            <button class="btn btn-sm btn-outline-secondary" id="navRateUpdateBtn"
                    onclick="updateExchangeRate()">🔄</button>
        </div>
    </div>
</nav>

<div class="container">

    <span class="badge badge-screen mb-2">🧮 계산기</span>
    <h2 class="fw-bold">월배당금 계산기</h2>
    <p class="text-muted">선택한 ETF의 월배당금 및 연배당금을 계산해보세요.</p>

    <div class="row g-2 mb-4">
        <div class="col-md-4 autocomplete-wrap">
            <input type="text" id="searchInput" class="form-control" autocomplete="off"
                placeholder="티커 입력 (예: JEPI)">
            <div class="autocomplete-box" id="autocompleteBox" style="display:none;"></div>
        </div>
        <div class="col-auto">
            <button class="btn btn-primary px-4" id="searchBtn">검색</button>
        </div>
        <div class="col-md-4">
            <select class="form-select" id="symbolSelect">
                <option value="">시총 상위 ETF 목록</option>
            </select>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-body d-flex align-items-center">
            <div class="logo-box me-3" id="logoBox">--</div>
            <div>
                <h5 class="mb-1" id="etfName">ETF를 먼저 선택해주세요</h5>
                <span class="badge bg-primary" id="symbolBadge"></span>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-6">
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="text-muted mb-2">1. 현재 환율 (1일 1회 업데이트)</h6>
                    <div class="fs-3 fw-bold" id="exchangeRate">조회 중...</div>
                </div>
            </div>
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="text-muted mb-2">2. 투자 정보 입력</h6>
                    <label class="form-label">투자금액 (원)</label>
                    <input type="text" id="investAmount" class="form-control" value="10,000,000">
                    <small class="text-muted" id="usdConverted">≈ $0.00 USD</small>
                    <button class="btn btn-primary w-100 py-2 mt-3" id="calculateBtn">🧮 계산하기</button>
                </div>
            </div>
            <div class="alert alert-light border small">
                ℹ️ 안내<br>
                · 환율은 1일 1회 업데이트됩니다.<br>
                · 투자금액은 원화 기준으로 입력해주세요.
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="text-muted mb-3">3. 배당률 및 세금 정보</h6>
                    <div class="row text-center">
                        <div class="col-4">
                            <div class="text-muted small">배당률 (연)</div>
                            <div class="fs-5 fw-bold text-success" id="divYield">-</div>
                        </div>
                        <div class="col-4">
                            <div class="text-muted small">세금</div>
                            <div class="fs-5 fw-bold">15.4%</div>
                        </div>
                        <div class="col-4">
                            <div class="text-muted small">세후 배당률 (연)</div>
                            <div class="fs-5 fw-bold text-success" id="afterTaxYield">-</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="text-muted mb-3">4. 계산 결과 (연 기준)</h6>
                    <div class="row g-2 text-center">
                        <div class="col-6">
                            <div class="result-card">
                                <div class="text-muted small">세전 월 배당금</div>
                                <div class="fs-5 fw-bold" id="beforeTaxMonthly">-</div>
                                <small class="text-muted" id="beforeTaxMonthlyUsd"></small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="result-card">
                                <div class="text-muted small">세후 월 배당금</div>
                                <div class="fs-5 fw-bold" id="afterTaxMonthly">-</div>
                                <small class="text-muted" id="afterTaxMonthlyUsd"></small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="result-card">
                                <div class="text-muted small">세전 연 배당금</div>
                                <div class="fs-5 fw-bold text-success" id="beforeTaxYearly">-</div>
                                <small class="text-muted" id="beforeTaxYearlyUsd"></small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="result-card">
                                <div class="text-muted small">세후 연 배당금</div>
                                <div class="fs-5 fw-bold text-success" id="afterTaxYearly">-</div>
                                <small class="text-muted" id="afterTaxYearlyUsd"></small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="alert alert-light border small my-4">
        ℹ️ 안내<br>
        · 배당금은 최근 12개월 지급 내역 기준으로 산출되며, 배당률 및 환율 변동에 따라 달라질 수 있습니다.<br>
        · 실제 투자 결과와 다를 수 있습니다.
    </div>

</div>

<script src="<%=request.getContextPath()%>/js/jquery.min.js"></script>
<script src="<%=request.getContextPath()%>/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
var contextPath = '<%=request.getContextPath()%>';
var currentSymbol = '';
var exchangeRateValue = 0;
var symbolList = [];

function updateExchangeRate() {
    var btn = document.getElementById('navRateUpdateBtn');
    btn.disabled = true;
    btn.innerText = '⏳';
    fetch(contextPath + '/exchange/update.do', { method: 'POST' })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.status === 'ok') {
                document.getElementById('navExchangeRate').innerText = Number(d.rate).toLocaleString();
                exchangeRateValue = Number(d.rate);
                document.getElementById('exchangeRate').innerText = exchangeRateValue.toLocaleString() + ' KRW / USD';
                btn.innerText = '✅';
            } else { btn.innerText = '❌'; }
            setTimeout(function() { btn.disabled = false; btn.innerText = '🔄'; }, 2000);
        });
}

window.addEventListener('DOMContentLoaded', function() {
    loadExchangeRate();
    loadSymbolList();
});

function loadExchangeRate() {
    fetch(contextPath + '/exchange/latest.do')
        .then(function(res) { return res.json(); })
        .then(function(rate) {
            exchangeRateValue = Number(rate.rate);
            document.getElementById('navExchangeRate').innerText = exchangeRateValue.toLocaleString();
            document.getElementById('exchangeRate').innerText = exchangeRateValue.toLocaleString() + ' KRW / USD';
        });
}

function loadSymbolList() {
    fetch(contextPath + '/etf/symbols.do')
        .then(function(res) { return res.json(); })
        .then(function(list) {
            symbolList = list;
            var select = document.getElementById('symbolSelect');
            list.forEach(function(item) {
                var opt = document.createElement('option');
                opt.value = item.symbol;
                opt.text = item.symbol + ' (배당률 ' + item.divYield + '%)';
                select.appendChild(opt);
            });
        });
}

// 자동완성
document.getElementById('searchInput').addEventListener('input', function() {
    var val = this.value.trim().toUpperCase();
    var box = document.getElementById('autocompleteBox');
    document.getElementById('symbolSelect').value = val;
    if (!val) { box.style.display = 'none'; return; }
    var filtered = symbolList.filter(function(item) {
        return item.symbol.toUpperCase().indexOf(val) === 0;
    });
    if (filtered.length === 0) { box.style.display = 'none'; return; }
    box.innerHTML = '';
    filtered.slice(0, 8).forEach(function(item) {
        var div = document.createElement('div');
        div.className = 'autocomplete-item';
        div.innerHTML = '<strong>' + item.symbol + '</strong> <span class="text-muted" style="font-size:0.8rem;">' + item.divYield + '%</span>';
        div.addEventListener('click', function() {
            document.getElementById('searchInput').value = item.symbol;
            document.getElementById('symbolSelect').value = item.symbol;
            box.style.display = 'none';
            loadEtfInfo(item.symbol);
        });
        box.appendChild(div);
    });
    box.style.display = 'block';
});

document.getElementById('searchInput').addEventListener('keydown', function(e) {
    var box = document.getElementById('autocompleteBox');
    var items = box.querySelectorAll('.autocomplete-item');
    var active = box.querySelector('.autocomplete-item.active');
    var idx = -1;
    items.forEach(function(item, i) { if (item === active) idx = i; });
    if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (idx < items.length - 1) { if (active) active.classList.remove('active'); items[idx+1].classList.add('active'); }
    } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (idx > 0) { if (active) active.classList.remove('active'); items[idx-1].classList.add('active'); }
    } else if (e.key === 'Enter') {
        if (active) { active.click(); }
        else { document.getElementById('searchBtn').click(); }
    } else if (e.key === 'Escape') {
        box.style.display = 'none';
    }
});

document.addEventListener('click', function(e) {
    var box = document.getElementById('autocompleteBox');
    var input = document.getElementById('searchInput');
    if (box && !box.contains(e.target) && e.target !== input) box.style.display = 'none';
});

document.getElementById('investAmount').addEventListener('input', function() {
    var val = this.value.replace(/,/g, '').replace(/[^0-9]/g, '');
    if (val) this.value = Number(val).toLocaleString();
});

document.getElementById('symbolSelect').addEventListener('change', function() {
    if (this.value) {
        document.getElementById('searchInput').value = this.value;
        document.getElementById('autocompleteBox').style.display = 'none';
        loadEtfInfo(this.value);
    }
});

document.getElementById('searchBtn').addEventListener('click', function() {
    var symbol = document.getElementById('searchInput').value.trim().toUpperCase();
    if (!symbol) { alert('티커를 입력해주세요.'); return; }
    loadEtfInfo(symbol);
});

function loadEtfInfo(symbol) {
    fetch(contextPath + '/etf/' + symbol + '/detail.do')
        .then(function(res) { return res.json(); })
        .then(function(data) {
            currentSymbol = symbol;
            document.getElementById('logoBox').innerText = symbol;
            document.getElementById('etfName').innerText = data.info.issuer || symbol;
            document.getElementById('symbolBadge').innerText = symbol;
            document.getElementById('divYield').innerText = data.info.divYield + '%';
            document.getElementById('afterTaxYield').innerText = data.info.afterTaxYield + '%';
            document.getElementById('symbolSelect').value = symbol;
        })
        .catch(function() {
            alert('해당 티커를 찾을 수 없습니다: ' + symbol);
            document.getElementById('searchInput').value = '';
            document.getElementById('symbolSelect').value = '';
        });
}

document.getElementById('calculateBtn').addEventListener('click', calculate);

function calculate() {
    if (!currentSymbol) { alert('종목을 먼저 선택해주세요.'); return; }
    var investAmount = document.getElementById('investAmount').value.replace(/,/g, '');
    fetch(contextPath + '/etf/' + currentSymbol + '/calculate.do?investAmount=' + investAmount)
        .then(function(res) { return res.json(); })
        .then(function(result) { renderResult(result); });
}

function renderResult(r) {
    document.getElementById('usdConverted').innerText = '≈ $' + r.investAmountUsd.toFixed(2) + ' USD';
    document.getElementById('beforeTaxMonthly').innerText = Math.round(r.beforeTaxMonthlyKrw).toLocaleString() + ' 원';
    document.getElementById('beforeTaxMonthlyUsd').innerText = '($' + r.beforeTaxMonthlyUsd.toFixed(2) + ')';
    document.getElementById('afterTaxMonthly').innerText = Math.round(r.afterTaxMonthlyKrw).toLocaleString() + ' 원';
    document.getElementById('afterTaxMonthlyUsd').innerText = '($' + r.afterTaxMonthlyUsd.toFixed(2) + ')';
    document.getElementById('beforeTaxYearly').innerText = Math.round(r.beforeTaxYearlyKrw).toLocaleString() + ' 원';
    document.getElementById('beforeTaxYearlyUsd').innerText = '($' + r.beforeTaxYearlyUsd.toFixed(2) + ')';
    document.getElementById('afterTaxYearly').innerText = Math.round(r.afterTaxYearlyKrw).toLocaleString() + ' 원';
    document.getElementById('afterTaxYearlyUsd').innerText = '($' + r.afterTaxYearlyUsd.toFixed(2) + ')';
}
</script>

</body>
</html>